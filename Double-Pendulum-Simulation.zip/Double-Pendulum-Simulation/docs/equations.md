# Equations of Motion

## Coordinate convention

Both angles are measured from the downward vertical, and both are **absolute angles** in the inertial frame:

- \(\theta_1\): angle of the first rod.
- \(\theta_2\): angle of the second rod.
- \(\omega_1 = \dot{\theta}_1\), \(\omega_2 = \dot{\theta}_2\).
- \(\alpha_1 = \ddot{\theta}_1\), \(\alpha_2 = \ddot{\theta}_2\).

Let \(\Delta = \theta_1 - \theta_2\), and let \(m_1,m_2\) and \(l_1,l_2\) denote the bob masses and rod lengths.

## Angular accelerations

Define the common denominator:

\[
D = 2m_1 + m_2 - m_2\cos(2\Delta)
\]

The first angular acceleration is:

\[
\alpha_1 = \frac{ -g(2m_1+m_2)\sin\theta_1
-m_2g\sin(\theta_1-2\theta_2)
-2m_2\sin\Delta\left(l_2\omega_2^2+l_1\omega_1^2\cos\Delta\right)}
{l_1D}
\]

The second angular acceleration is:

\[
\alpha_2 = \frac{2\sin\Delta\left[l_1\omega_1^2(m_1+m_2)
+g(m_1+m_2)\cos\theta_1
+l_2m_2\omega_2^2\cos\Delta\right]}
{l_2D}
\]

## First-order state-space form

The second-order equations are written as four first-order equations:

\[
\dot{\theta}_1=\omega_1,\qquad
\dot{\theta}_2=\omega_2
\]

\[
\dot{\omega}_1=\alpha_1,\qquad
\dot{\omega}_2=\alpha_2
\]

This is the derivative vector returned by the NetLogo reporter `derivatives`.

## RK4 update

For a state vector \(\mathbf{x}\), derivative function \(f\), and time step \(h=dt\):

\[
\begin{aligned}
k_1 &= f(\mathbf{x}_n)\\
k_2 &= f(\mathbf{x}_n + \tfrac{h}{2}k_1)\\
k_3 &= f(\mathbf{x}_n + \tfrac{h}{2}k_2)\\
k_4 &= f(\mathbf{x}_n + hk_3)\\
\mathbf{x}_{n+1} &= \mathbf{x}_n + \tfrac{h}{6}(k_1+2k_2+2k_3+k_4)
\end{aligned}
\]

In the model, five RK4 steps are performed for each displayed NetLogo tick.
