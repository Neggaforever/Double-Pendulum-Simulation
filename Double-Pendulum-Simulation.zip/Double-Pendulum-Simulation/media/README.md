# Media assets

- `double_pendulum_demo.mp4`: original screen recording supplied for this project.
- `simulation.gif`: cropped animated preview of the NetLogo simulation world, prepared from the supplied recording.
- `thumbnail.png`: representative screenshot of the NetLogo application during the simulation.
